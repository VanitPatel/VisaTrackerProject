# VisaTrack Pro — Backend

Production-grade FastAPI backend for the VisaTrack Pro immigration intelligence platform.

---

## Architecture

```
visatrack-backend/
├── main.py                         # App entry point + router registration
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── .env.example
│
├── config/
│   ├── settings.py                 # Pydantic-settings (typed .env)
│   ├── database.py                 # PostgreSQL + MongoDB connections
│   └── redis.py                    # Async Redis helpers
│
└── app/
    ├── models/                     # SQLAlchemy ORM models
    │   ├── user.py                 # User, Organization, RefreshToken
    │   ├── case.py                 # Case (USCIS receipt tracking)
    │   ├── document.py             # Document, Notification
    │   └── billing.py              # Subscription, Invoice
    │
    ├── schemas/                    # Pydantic request/response schemas
    │   └── __init__.py
    │
    ├── services/                   # Business logic
    │   ├── auth_service.py         # JWT, bcrypt, token rotation
    │   ├── uscis_service.py        # USCIS API proxy (OAuth2)
    │   ├── case_service.py         # Case CRUD + notification push
    │   └── document_service.py     # Upload, S3/local, signed URLs
    │
    ├── routes/                     # FastAPI routers
    │   ├── auth.py                 # /auth/*
    │   ├── cases.py                # /cases/* + live check
    │   └── documents.py            # /documents/*, /notifications/*, /ai/*, /reports/*
    │
    └── middleware/
        └── auth.py                 # JWT dependency, RBAC, rate limiter, logging
```

---

## Quick Start

### 1. Local development

```bash
# Clone and enter
cd visatrack-backend

# Create venv
python -m venv .venv && source .venv/bin/activate

# Install deps
pip install -r requirements.txt

# Configure
cp .env.example .env
# Edit .env — at minimum fill in:
#   SECRET_KEY, JWT_SECRET_KEY, DATABASE_URL
#   USCIS_CLIENT_ID, USCIS_CLIENT_SECRET

# Run (auto-creates PG tables on first start)
uvicorn main:app --reload --port 8000
```

### 2. Docker (recommended)

```bash
cp .env.example .env   # fill in real secrets
docker-compose up --build
```

API available at: `http://localhost:8000`
Swagger docs: `http://localhost:8000/docs`

---

## API Endpoints

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/api/v1/auth/register` | — | Create account |
| POST | `/api/v1/auth/login` | — | Sign in, get tokens |
| POST | `/api/v1/auth/refresh` | — | Rotate refresh token |
| POST | `/api/v1/auth/logout` | ✅ | Revoke refresh token |
| GET  | `/api/v1/auth/me` | ✅ | Current user |
| GET  | `/api/v1/cases` | ✅ | List user's cases |
| POST | `/api/v1/cases` | ✅ | Add case + immediate USCIS lookup |
| GET  | `/api/v1/cases/{id}` | ✅ | Case detail |
| PUT  | `/api/v1/cases/{id}` | ✅ | Update case metadata |
| DELETE | `/api/v1/cases/{id}` | ✅ | Remove case |
| POST | `/api/v1/cases/{id}/refresh` | ✅ | Force USCIS API refresh |
| GET  | `/api/v1/cases/check/{receipt}` | ✅ | Live status check |
| GET  | `/api/v1/documents` | ✅ | List documents |
| POST | `/api/v1/documents` | ✅ | Upload document |
| DELETE | `/api/v1/documents/{id}` | ✅ | Delete document |
| GET  | `/api/v1/notifications` | ✅ | List notifications |
| POST | `/api/v1/notifications/{id}/read` | ✅ | Mark read |
| POST | `/api/v1/notifications/mark-all-read` | ✅ | Mark all read |
| POST | `/api/v1/ai/chat` | ✅ | AI assistant chat |
| POST | `/api/v1/reports/generate` | ✅ | Generate report |
| GET  | `/api/check-status/{receipt}` | — | Legacy compat (matches original HTML) |
| GET  | `/health` | — | Health check |

---

## Frontend Integration Guide

### Step 1 — Replace `doAuth()` in your HTML

```javascript
// Replace the existing doAuth() function:
async function doAuth() {
  const fn    = document.getElementById('aFn').value.trim();
  const ln    = document.getElementById('aLn').value.trim();
  const em    = document.getElementById('aEm').value.trim();
  const pw    = document.getElementById('aPw').value;

  if (!fn || !em || !pw) {
    showToast('Please fill in all fields', 'amber');
    return;
  }

  showLoader('Creating account…');
  try {
    const res = await fetch('/api/v1/auth/register', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        first_name: fn,
        last_name:  ln,
        email:      em,
        password:   pw,
        role:       authRole,
        country:    document.getElementById('aCtry').value,
      }),
    });
    const data = await res.json();
    if (!data.success) throw new Error(data.error);

    // Store tokens
    localStorage.setItem('vt_access',  data.data.tokens.access_token);
    localStorage.setItem('vt_refresh', data.data.tokens.refresh_token);

    // Merge user data into S
    const u = data.data.user;
    S.user  = { fn: u.first_name, ln: u.last_name, email: u.email, initials: u.initials };
    S.role  = u.role;

    hideLoader();
    document.getElementById('scr-auth').style.display = 'none';
    document.getElementById('shell').style.display    = 'flex';
    initApp();
  } catch (err) {
    hideLoader();
    showToast('Registration failed: ' + err.message, 'rose');
  }
}

// Helper: authenticated fetch
async function apiFetch(path, opts = {}) {
  const token = localStorage.getItem('vt_access');
  const res = await fetch('/api/v1' + path, {
    ...opts,
    headers: {
      'Content-Type':  'application/json',
      'Authorization': `Bearer ${token}`,
      ...(opts.headers || {}),
    },
  });

  // Auto-refresh on 401
  if (res.status === 401) {
    const refreshed = await refreshTokens();
    if (refreshed) return apiFetch(path, opts);  // retry once
    doSignout();
    return null;
  }
  return res.json();
}

async function refreshTokens() {
  const rt  = localStorage.getItem('vt_refresh');
  if (!rt) return false;
  const res = await fetch('/api/v1/auth/refresh', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ refresh_token: rt }),
  });
  if (!res.ok) return false;
  const data = await res.json();
  localStorage.setItem('vt_access',  data.data.access_token);
  localStorage.setItem('vt_refresh', data.data.refresh_token);
  return true;
}
```

### Step 2 — Replace `submitAddCase()`

```javascript
async function submitAddCase() {
  const num  = (document.getElementById('mcNum')?.value || '').trim().toUpperCase();
  const visa = document.getElementById('mcVisa')?.value || '';
  const proc = document.getElementById('mcProc')?.value || 'Regular';

  closeModal();
  showLoader('Fetching case ' + num + ' from USCIS API…');

  const data = await apiFetch('/cases', {
    method: 'POST',
    body: JSON.stringify({
      receipt_number:  num,
      visa_type:       visa,
      processing_type: proc,
    }),
  });

  hideLoader();
  if (!data?.success) {
    showToast('Error: ' + (data?.error || 'Unknown'), 'amber');
    return;
  }

  const c = data.data;
  // Reload cases from server
  await loadCasesFromServer();
  showToast(num + ' added — ' + (c.api_snapshot?.label || 'Tracked') + ' ✓', 'emerald');
}

async function loadCasesFromServer() {
  const data = await apiFetch('/cases');
  if (!data?.success) return;
  S.cases = data.data.cases.map(c => ({
    receiptNum:  c.receipt_number,
    visaType:    c.visa_type || '',
    processing:  c.processing_type,
    addedAt:     c.created_at,
    apiData:     c.api_snapshot || {},
    _id:         c.id,           // DB id for server ops
  }));
  updateSidebarCounts();
  renderDashboard();
  renderCasesScreen();
}
```

### Step 3 — Replace `triggerLiveCheck()`

```javascript
// The backend already serves /api/check-status/{num}
// No change needed — the existing HTML's USCISScraper.checkStatus()
// calls /api/check-status/${num} which maps to the legacy shim endpoint.
//
// For the full authenticated version use:
async function triggerLiveCheck() {
  const num = document.getElementById('liveCheckInput').value.trim().toUpperCase();
  // ... validation ...
  const data = await apiFetch(`/cases/check/${num}`);
  // ... render result ...
}
```

### Step 4 — Replace `sendChat()`

```javascript
let chatHistory = [];

async function sendChat() {
  const ta  = document.getElementById('chatInput');
  const msg = ta.value.trim();
  if (!msg) return;
  ta.value = '';

  appendMsg('user', msg);
  showTyping();
  chatHistory.push({ role: 'user', content: msg });

  const data = await apiFetch('/ai/chat', {
    method: 'POST',
    body: JSON.stringify({ message: msg, history: chatHistory.slice(-10) }),
  });

  document.getElementById('typing')?.remove();
  const reply = data?.data?.reply || 'Something went wrong. Please try again.';
  appendMsg('ai', reply);
  chatHistory.push({ role: 'assistant', content: reply });
}
```

---

## Security Checklist

| Item | Status |
|------|--------|
| API keys never exposed to browser | ✅ |
| Passwords hashed with bcrypt (cost 12) | ✅ |
| JWT access tokens (30min) + refresh rotation | ✅ |
| Role-based access control (5 roles) | ✅ |
| Rate limiting on all endpoints | ✅ |
| CORS configured per environment | ✅ |
| USCIS credentials stored server-side only | ✅ |
| File upload validation (type + size) | ✅ |
| SQL injection impossible (SQLAlchemy ORM) | ✅ |
| HTTPS redirect in production | ✅ |
| Request ID tracing on every response | ✅ |
| Input validation via Pydantic | ✅ |

---

## Environment Variables (required)

```
SECRET_KEY            — 64-char random hex
JWT_SECRET_KEY        — 64-char random hex (different from SECRET_KEY)
DATABASE_URL          — postgresql+asyncpg://user:pass@host:5432/db
USCIS_CLIENT_ID       — from USCIS developer portal
USCIS_CLIENT_SECRET   — from USCIS developer portal
```

All other vars default safely. See `.env.example` for full list.
