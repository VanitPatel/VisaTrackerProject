# main.py
# ═══════════════════════════════════════════════════════
#  VisaTrack Pro — FastAPI Application Entry Point
#
#  Start with:
#    uvicorn main:app --reload --port 8000
#
#  Or via Docker:
#    docker-compose up
# ═══════════════════════════════════════════════════════

from contextlib import asynccontextmanager

import structlog
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware

from app.middleware.auth import RequestLoggingMiddleware, limiter
from app.routes.auth import router as auth_router
from app.routes.cases import router as cases_router
from app.routes.documents import router as docs_router
from app.routes.documents import notif_router, ai_router, reports_router
from config.database import init_db, close_db
from config.redis import close_redis
from config.settings import settings

# ── Structured logging setup ──────────────────────────
structlog.configure(
    processors=[
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.dev.ConsoleRenderer() if settings.debug else structlog.processors.JSONRenderer(),
    ],
    wrapper_class=structlog.make_filtering_bound_logger(20),  # INFO+
    context_class=dict,
    logger_factory=structlog.PrintLoggerFactory(),
)

log = structlog.get_logger()


# ── App lifespan ──────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info("visatrack.startup", env=settings.app_env, version=settings.app_version)
    await init_db()
    yield
    log.info("visatrack.shutdown")
    await close_db()
    await close_redis()


# ── App factory ───────────────────────────────────────
app = FastAPI(
    title       = "VisaTrack Pro API",
    description = "Production-grade immigration case tracking backend",
    version     = settings.app_version,
    docs_url    = "/docs" if not settings.is_production else None,
    redoc_url   = "/redoc" if not settings.is_production else None,
    lifespan    = lifespan,
)

# ── Rate limiter ──────────────────────────────────────
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.add_middleware(SlowAPIMiddleware)

# ── CORS ──────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins     = settings.cors_origins_list,
    allow_credentials = True,
    allow_methods     = ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
    allow_headers     = ["*"],
)

# ── Request logging ───────────────────────────────────
app.add_middleware(RequestLoggingMiddleware)

# ── Security headers (production) ────────────────────
if settings.is_production:
    from starlette.middleware.httpsredirect import HTTPSRedirectMiddleware
    app.add_middleware(HTTPSRedirectMiddleware)


# ── Routers ───────────────────────────────────────────
API_PREFIX = "/api/v1"

app.include_router(auth_router,     prefix=API_PREFIX)
app.include_router(cases_router,    prefix=API_PREFIX)
app.include_router(docs_router,     prefix=API_PREFIX)
app.include_router(notif_router,    prefix=API_PREFIX)
app.include_router(ai_router,       prefix=API_PREFIX)
app.include_router(reports_router,  prefix=API_PREFIX)


# ── Global error handler ──────────────────────────────
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    log.error("unhandled_exception", path=request.url.path, error=str(exc))
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"success": False, "data": None, "error": "Internal server error"},
    )


@app.exception_handler(404)
async def not_found_handler(request: Request, exc):
    return JSONResponse(
        status_code=404,
        content={"success": False, "data": None, "error": "Not found"},
    )


# ── Health check ──────────────────────────────────────
@app.get("/health", tags=["Health"])
async def health():
    return {
        "status":  "ok",
        "version": settings.app_version,
        "env":     settings.app_env,
    }


# ── Legacy frontend-compatible endpoint ──────────────
# The original HTML calls /api/check-status/{num}
# This thin shim keeps backward compatibility.

from app.services.uscis_service import check_case_status, validate_receipt_number
from fastapi import HTTPException

@app.get("/api/check-status/{receipt_number}")
async def legacy_status_check(receipt_number: str):
    """
    Backward-compatible endpoint matching the original frontend's
    fetch(`/api/check-status/${num}`) call.

    No auth required on this shim so the unmodified HTML file still works.
    For production, point frontend to the authenticated /api/v1/cases/check/{num}.
    """
    num = receipt_number.upper()
    if not validate_receipt_number(num):
        raise HTTPException(status_code=400, detail="Invalid receipt number format")
    result = await check_case_status(num)
    return result


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host    = settings.host,
        port    = settings.port,
        reload  = settings.debug,
        workers = 1 if settings.debug else settings.workers,
    )
