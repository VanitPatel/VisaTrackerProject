# config/settings.py
# ═══════════════════════════════════════════════════════
#  Centralised settings loaded from .env
#  Using pydantic-settings for validation + type safety
# ═══════════════════════════════════════════════════════

from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import AnyUrl, field_validator
from functools import lru_cache
from typing import List


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── App ────────────────────────────────────────────
    app_env: str = "development"
    app_name: str = "VisaTrack Pro"
    app_version: str = "1.0.0"
    secret_key: str
    debug: bool = False

    # ── Server ─────────────────────────────────────────
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 4

    # ── PostgreSQL ─────────────────────────────────────
    database_url: str
    database_pool_size: int = 20
    database_max_overflow: int = 10

    # ── MongoDB ────────────────────────────────────────
    mongodb_url: str = "mongodb://localhost:27017/visatrack_docs"
    mongodb_db_name: str = "visatrack_docs"

    # ── Redis ──────────────────────────────────────────
    redis_url: str = "redis://localhost:6379/0"
    redis_ttl_seconds: int = 300

    # ── JWT ────────────────────────────────────────────
    jwt_secret_key: str
    jwt_algorithm: str = "HS256"
    jwt_access_token_expire_minutes: int = 30
    jwt_refresh_token_expire_days: int = 30

    # ── USCIS ──────────────────────────────────────────
    uscis_client_id: str
    uscis_client_secret: str
    uscis_token_url: str = "https://api-int.uscis.gov/oauth/accesstoken"
    uscis_api_base: str = "https://api-int.uscis.gov"
    uscis_cache_ttl: int = 300

    # ── OpenAI ─────────────────────────────────────────
    openai_api_key: str = ""
    openai_model: str = "gpt-4o"
    openai_max_tokens: int = 1000

    # ── SendGrid ───────────────────────────────────────
    sendgrid_api_key: str = ""
    email_from: str = "noreply@visatrackpro.com"
    email_from_name: str = "VisaTrack Pro"

    # ── Twilio ─────────────────────────────────────────
    twilio_account_sid: str = ""
    twilio_auth_token: str = ""
    twilio_phone_number: str = ""

    # ── Stripe ─────────────────────────────────────────
    stripe_secret_key: str = ""
    stripe_webhook_secret: str = ""
    stripe_price_pro: str = ""
    stripe_price_enterprise: str = ""

    # ── Storage ────────────────────────────────────────
    storage_backend: str = "local"
    local_upload_dir: str = "./uploads"
    max_upload_mb: int = 10
    aws_access_key_id: str = ""
    aws_secret_access_key: str = ""
    aws_s3_bucket: str = "visatrack-documents"
    aws_s3_region: str = "us-east-1"

    # ── CORS ───────────────────────────────────────────
    cors_origins: str = "http://localhost:3000"

    # ── Rate limiting ──────────────────────────────────
    rate_limit_per_minute: int = 60
    rate_limit_auth_per_minute: int = 10

    @property
    def cors_origins_list(self) -> List[str]:
        return [o.strip() for o in self.cors_origins.split(",")]

    @property
    def is_production(self) -> bool:
        return self.app_env == "production"


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
