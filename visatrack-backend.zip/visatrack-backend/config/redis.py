# config/redis.py
# ═══════════════════════════════════════════════════════
#  Async Redis client — token cache, rate limiting, sessions
# ═══════════════════════════════════════════════════════

import json
from typing import Any, Optional
import redis.asyncio as aioredis
import structlog

from config.settings import settings

log = structlog.get_logger()
_redis: Optional[aioredis.Redis] = None


async def get_redis() -> aioredis.Redis:
    global _redis
    if _redis is None:
        _redis = await aioredis.from_url(
            settings.redis_url,
            encoding="utf-8",
            decode_responses=True,
        )
    return _redis


async def close_redis():
    global _redis
    if _redis:
        await _redis.aclose()
        _redis = None


# ── Convenience helpers ───────────────────────────────

async def cache_set(key: str, value: Any, ttl: int = settings.redis_ttl_seconds):
    r = await get_redis()
    await r.setex(key, ttl, json.dumps(value))


async def cache_get(key: str) -> Optional[Any]:
    r = await get_redis()
    raw = await r.get(key)
    return json.loads(raw) if raw else None


async def cache_delete(key: str):
    r = await get_redis()
    await r.delete(key)


async def cache_invalidate_prefix(prefix: str):
    """Delete all keys matching a prefix pattern."""
    r = await get_redis()
    keys = await r.keys(f"{prefix}*")
    if keys:
        await r.delete(*keys)
