# config/database.py
# ═══════════════════════════════════════════════════════
#  PostgreSQL (SQLAlchemy async) + MongoDB (Motor) setup
# ═══════════════════════════════════════════════════════

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase
from motor.motor_asyncio import AsyncIOMotorClient
from typing import AsyncGenerator
import structlog

from config.settings import settings

log = structlog.get_logger()

# ── PostgreSQL ────────────────────────────────────────

engine = create_async_engine(
    settings.database_url,
    pool_size=settings.database_pool_size,
    max_overflow=settings.database_max_overflow,
    echo=settings.debug,
    future=True,
)

AsyncSessionLocal = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autoflush=False,
)


class Base(DeclarativeBase):
    pass


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency: yields an async DB session."""
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


# ── MongoDB ───────────────────────────────────────────

_mongo_client: AsyncIOMotorClient | None = None


def get_mongo_client() -> AsyncIOMotorClient:
    global _mongo_client
    if _mongo_client is None:
        _mongo_client = AsyncIOMotorClient(settings.mongodb_url)
    return _mongo_client


def get_mongo_db():
    return get_mongo_client()[settings.mongodb_db_name]


# ── Lifecycle helpers ─────────────────────────────────

async def init_db():
    """Create all PG tables on startup (dev). Use Alembic in prod."""
    from app.models import user, case, document, notification, billing  # noqa: F401
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    log.info("PostgreSQL tables initialised")


async def close_db():
    await engine.dispose()
    if _mongo_client:
        _mongo_client.close()
    log.info("Database connections closed")
