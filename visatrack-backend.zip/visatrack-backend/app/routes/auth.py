# app/routes/auth.py
# ═══════════════════════════════════════════════════════
#  Auth endpoints: register, login, refresh, logout
# ═══════════════════════════════════════════════════════

from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.middleware.auth import get_current_user, limiter
from app.models.user import User
from app.schemas import (
    RegisterRequest, LoginRequest, LoginResponse, RefreshRequest,
    TokenResponse, UserResponse, APIResponse,
)
from app.services import auth_service
from config.database import get_db
from config.settings import settings

router = APIRouter(prefix="/auth", tags=["Authentication"])


def _user_response(user: User) -> UserResponse:
    return UserResponse(
        id                = str(user.id),
        email             = user.email,
        first_name        = user.first_name,
        last_name         = user.last_name,
        role              = user.role.value,
        initials          = user.initials,
        subscription_tier = user.subscription_tier.value,
        is_verified       = user.is_verified,
        created_at        = user.created_at.isoformat(),
    )


@router.post("/register", response_model=APIResponse, status_code=status.HTTP_201_CREATED)
@limiter.limit(f"{settings.rate_limit_auth_per_minute}/minute")
async def register(
    request: Request,
    body:    RegisterRequest,
    db:      AsyncSession = Depends(get_db),
):
    try:
        user = await auth_service.register_user(
            db,
            email      = body.email,
            password   = body.password,
            first_name = body.first_name,
            last_name  = body.last_name,
            role       = body.role,
            country    = body.country or "us",
        )
        access, refresh = await auth_service.issue_tokens(
            db, user,
            ip_address = request.client.host if request.client else None,
            user_agent = request.headers.get("user-agent"),
        )
        return APIResponse(
            data={
                "tokens": TokenResponse(
                    access_token  = access,
                    refresh_token = refresh,
                    expires_in    = settings.jwt_access_token_expire_minutes * 60,
                ).model_dump(),
                "user": _user_response(user).model_dump(),
            }
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))


@router.post("/login", response_model=APIResponse)
@limiter.limit(f"{settings.rate_limit_auth_per_minute}/minute")
async def login(
    request: Request,
    body:    LoginRequest,
    db:      AsyncSession = Depends(get_db),
):
    try:
        user = await auth_service.authenticate_user(db, body.email, body.password)
        access, refresh = await auth_service.issue_tokens(
            db, user,
            ip_address = request.client.host if request.client else None,
            user_agent = request.headers.get("user-agent"),
        )
        return APIResponse(
            data={
                "tokens": TokenResponse(
                    access_token  = access,
                    refresh_token = refresh,
                    expires_in    = settings.jwt_access_token_expire_minutes * 60,
                ).model_dump(),
                "user": _user_response(user).model_dump(),
            }
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(e))


@router.post("/refresh", response_model=APIResponse)
async def refresh(
    request: Request,
    body:    RefreshRequest,
    db:      AsyncSession = Depends(get_db),
):
    try:
        access, refresh = await auth_service.rotate_refresh_token(
            db, body.refresh_token,
            ip_address = request.client.host if request.client else None,
            user_agent = request.headers.get("user-agent"),
        )
        return APIResponse(
            data=TokenResponse(
                access_token  = access,
                refresh_token = refresh,
                expires_in    = settings.jwt_access_token_expire_minutes * 60,
            ).model_dump()
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(e))


@router.post("/logout", response_model=APIResponse)
async def logout(
    body: RefreshRequest,
    db:   AsyncSession = Depends(get_db),
    _:    User         = Depends(get_current_user),
):
    await auth_service.revoke_refresh_token(db, body.refresh_token)
    return APIResponse(data={"message": "Logged out successfully"})


@router.get("/me", response_model=APIResponse)
async def me(current_user: User = Depends(get_current_user)):
    return APIResponse(data=_user_response(current_user).model_dump())
