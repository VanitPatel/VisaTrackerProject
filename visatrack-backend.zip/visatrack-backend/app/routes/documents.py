# app/routes/documents.py
# ═══════════════════════════════════════════════════════
#  Document upload, listing, and download endpoints
# ═══════════════════════════════════════════════════════

import uuid
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.middleware.auth import get_current_user
from app.models.user import User
from app.models.document import Document
from app.schemas import APIResponse
from app.services.document_service import save_document, get_download_url
from config.database import get_db

router = APIRouter(prefix="/documents", tags=["Documents"])


@router.get("", response_model=APIResponse)
async def list_documents(
    case_id:      uuid.UUID | None = None,
    db:           AsyncSession     = Depends(get_db),
    current_user: User             = Depends(get_current_user),
):
    q = select(Document).where(Document.user_id == current_user.id)
    if case_id:
        q = q.where(Document.case_id == case_id)
    result = await db.execute(q.order_by(Document.uploaded_at.desc()))
    docs = result.scalars().all()

    def _doc(d):
        return {
            "id":                  str(d.id),
            "case_id":             str(d.case_id),
            "name":                d.name,
            "doc_type":            d.doc_type,
            "file_size_bytes":     d.file_size_bytes,
            "verification_status": d.verification_status.value,
            "ocr_processed":       d.ocr_processed,
            "uploaded_at":         d.uploaded_at.isoformat(),
            "download_url":        get_download_url(d.storage_key),
        }
    return APIResponse(data={"documents": [_doc(d) for d in docs]})


@router.post("", response_model=APIResponse, status_code=status.HTTP_201_CREATED)
async def upload_document(
    file:         UploadFile,
    case_id:      str               = Form(...),
    doc_type:     str               = Form("Document"),
    db:           AsyncSession      = Depends(get_db),
    current_user: User              = Depends(get_current_user),
):
    content = await file.read()
    content_type = file.content_type or "application/octet-stream"

    try:
        storage_key = await save_document(
            file_bytes   = content,
            filename     = file.filename or "upload",
            content_type = content_type,
            user_id      = str(current_user.id),
            case_id      = case_id,
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

    doc = Document(
        case_id           = uuid.UUID(case_id),
        user_id           = current_user.id,
        name              = file.filename or "upload",
        original_filename = file.filename,
        doc_type          = doc_type,
        mime_type         = content_type,
        file_size_bytes   = len(content),
        storage_key       = storage_key,
    )
    db.add(doc)
    await db.flush()

    return APIResponse(data={
        "id":                  str(doc.id),
        "name":                doc.name,
        "doc_type":            doc.doc_type,
        "file_size_bytes":     doc.file_size_bytes,
        "verification_status": doc.verification_status.value,
        "storage_key":         storage_key,
        "download_url":        get_download_url(storage_key),
    })


@router.delete("/{doc_id}", response_model=APIResponse)
async def delete_document(
    doc_id:       uuid.UUID,
    db:           AsyncSession = Depends(get_db),
    current_user: User         = Depends(get_current_user),
):
    result = await db.execute(
        select(Document).where(Document.id == doc_id, Document.user_id == current_user.id)
    )
    doc = result.scalar_one_or_none()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    await db.delete(doc)
    return APIResponse(data={"message": "Document deleted"})


# ─────────────────────────────────────────────────────
# app/routes/notifications.py
# ─────────────────────────────────────────────────────

from fastapi import APIRouter as _APIRouter
from app.services.case_service import (
    get_user_notifications, mark_read, mark_all_read
)

notif_router = _APIRouter(prefix="/notifications", tags=["Notifications"])


@notif_router.get("", response_model=APIResponse)
async def list_notifications(
    unread_only:  bool         = False,
    limit:        int          = 50,
    db:           AsyncSession = Depends(get_db),
    current_user: User         = Depends(get_current_user),
):
    items = await get_user_notifications(db, current_user.id, unread_only, limit)
    unread_count = sum(1 for n in items if not n.is_read)

    def _n(n):
        return {
            "id":         str(n.id),
            "type":       n.type.value,
            "title":      n.title,
            "message":    n.message,
            "icon":       n.icon,
            "priority":   n.priority,
            "is_read":    n.is_read,
            "case_id":    str(n.case_id) if n.case_id else None,
            "created_at": n.created_at.isoformat(),
        }
    return APIResponse(
        data={"notifications": [_n(n) for n in items]},
        meta={"unread_count": unread_count},
    )


@notif_router.post("/{notif_id}/read", response_model=APIResponse)
async def mark_notification_read(
    notif_id:     uuid.UUID,
    db:           AsyncSession = Depends(get_db),
    current_user: User         = Depends(get_current_user),
):
    await mark_read(db, notif_id, current_user.id)
    return APIResponse(data={"message": "Marked as read"})


@notif_router.post("/mark-all-read", response_model=APIResponse)
async def mark_all_notifications_read(
    db:           AsyncSession = Depends(get_db),
    current_user: User         = Depends(get_current_user),
):
    await mark_all_read(db, current_user.id)
    return APIResponse(data={"message": "All notifications marked as read"})


# ─────────────────────────────────────────────────────
# app/routes/ai.py
# ─────────────────────────────────────────────────────

from pydantic import BaseModel as _BM
from app.services.case_service import get_user_cases as _get_cases
from app.services.case_service import ai_chat

ai_router = _APIRouter(prefix="/ai", tags=["AI Assistant"])


class ChatRequest(_BM):
    message: str
    history: list = []


@ai_router.post("/chat", response_model=APIResponse)
async def chat(
    body:         ChatRequest,
    db:           AsyncSession = Depends(get_db),
    current_user: User         = Depends(get_current_user),
):
    cases = await _get_cases(db, current_user.id)
    case_ctx = {
        "cases": [
            {
                "receipt_number": c.receipt_number,
                "visa_type":      c.visa_type,
                "status":         c.status.value,
                "form_type":      c.form_type,
            }
            for c in cases
        ],
        "role":  current_user.role.value,
        "name":  current_user.full_name,
    }
    reply = await ai_chat(body.message, case_ctx, body.history)
    return APIResponse(data={"reply": reply})


# ─────────────────────────────────────────────────────
# app/routes/reports.py
# ─────────────────────────────────────────────────────

from io import BytesIO
from datetime import date as _date
from fastapi.responses import StreamingResponse
from pydantic import BaseModel as _BM2
from typing import Optional as _Opt

reports_router = _APIRouter(prefix="/reports", tags=["Reports"])


class ReportRequest(_BM2):
    report_type: str        # compliance | portfolio | budget
    from_date:   _Opt[str] = None
    to_date:     _Opt[str] = None
    format:      str = "pdf"   # pdf | csv


@reports_router.post("/generate", response_model=APIResponse)
async def generate_report(
    body:         ReportRequest,
    db:           AsyncSession = Depends(get_db),
    current_user: User         = Depends(get_current_user),
):
    """Stub: generates a PDF/CSV compliance report. Extend with reportlab/openpyxl."""
    cases = await _get_cases(db, current_user.id)

    # TODO: integrate reportlab for real PDF generation
    summary = {
        "report_type":  body.report_type,
        "generated_at": _date.today().isoformat(),
        "generated_by": current_user.full_name,
        "case_count":   len(cases),
        "cases": [
            {
                "receipt_number": c.receipt_number,
                "visa_type":      c.visa_type,
                "status":         c.status.value,
                "submitted_date": c.submitted_date,
            }
            for c in cases
        ],
    }
    return APIResponse(data={"report": summary, "message": f"{body.report_type.capitalize()} report generated"})
