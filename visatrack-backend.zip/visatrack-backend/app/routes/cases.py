# app/routes/cases.py
# ═══════════════════════════════════════════════════════
#  Case endpoints — CRUD + live USCIS status proxy
# ═══════════════════════════════════════════════════════

import uuid
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.middleware.auth import get_current_user
from app.models.user import User
from app.schemas import APIResponse, CaseCreateRequest, CaseUpdateRequest
from app.services import case_service
from config.database import get_db

router = APIRouter(prefix="/cases", tags=["Cases"])


def _serialize_case(c) -> dict:
    return {
        "id":              str(c.id),
        "receipt_number":  c.receipt_number,
        "visa_type":       c.visa_type,
        "form_type":       c.form_type,
        "processing_type": c.processing_type,
        "status":          c.status.value,
        "priority":        c.priority,
        "submitted_date":  c.submitted_date,
        "modified_date":   c.modified_date,
        "api_snapshot":    c.api_snapshot,
        "timeline_events": c.timeline_events or [],
        "last_checked_at": c.last_checked_at.isoformat() if c.last_checked_at else None,
        "notes":           c.notes,
        "created_at":      c.created_at.isoformat(),
        "updated_at":      c.updated_at.isoformat(),
    }


@router.get("", response_model=APIResponse)
async def list_cases(
    db:           AsyncSession = Depends(get_db),
    current_user: User         = Depends(get_current_user),
):
    cases = await case_service.get_user_cases(db, current_user.id)
    return APIResponse(
        data={"cases": [_serialize_case(c) for c in cases]},
        meta={"count": len(cases)},
    )


@router.post("", response_model=APIResponse, status_code=status.HTTP_201_CREATED)
async def create_case(
    body:         CaseCreateRequest,
    db:           AsyncSession = Depends(get_db),
    current_user: User         = Depends(get_current_user),
):
    try:
        case = await case_service.create_case(
            db,
            user_id         = current_user.id,
            receipt_number  = body.receipt_number,
            visa_type       = body.visa_type,
            processing_type = body.processing_type,
            notes           = body.notes,
            priority        = body.priority,
        )
        return APIResponse(data=_serialize_case(case))
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get("/{case_id}", response_model=APIResponse)
async def get_case(
    case_id:      uuid.UUID,
    db:           AsyncSession = Depends(get_db),
    current_user: User         = Depends(get_current_user),
):
    case = await case_service.get_case(db, case_id, current_user.id)
    if not case:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Case not found")
    return APIResponse(data=_serialize_case(case))


@router.put("/{case_id}", response_model=APIResponse)
async def update_case(
    case_id:      uuid.UUID,
    body:         CaseUpdateRequest,
    db:           AsyncSession = Depends(get_db),
    current_user: User         = Depends(get_current_user),
):
    case = await case_service.get_case(db, case_id, current_user.id)
    if not case:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Case not found")

    await case_service.update_case(db, case, **body.model_dump(exclude_none=True))
    return APIResponse(data=_serialize_case(case))


@router.delete("/{case_id}", response_model=APIResponse)
async def delete_case(
    case_id:      uuid.UUID,
    db:           AsyncSession = Depends(get_db),
    current_user: User         = Depends(get_current_user),
):
    case = await case_service.get_case(db, case_id, current_user.id)
    if not case:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Case not found")
    await case_service.delete_case(db, case)
    return APIResponse(data={"message": "Case deleted"})


@router.post("/{case_id}/refresh", response_model=APIResponse)
async def refresh_case_status(
    case_id:      uuid.UUID,
    db:           AsyncSession = Depends(get_db),
    current_user: User         = Depends(get_current_user),
):
    """Force a fresh USCIS API call, bypass cache."""
    case = await case_service.get_case(db, case_id, current_user.id)
    if not case:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Case not found")

    result = await case_service.refresh_case_status(db, case, force=True)
    return APIResponse(
        data={
            "case":         _serialize_case(case),
            "uscis_result": result,
        }
    )


# ── USCIS live check (no stored case required) ────────

from app.services.uscis_service import check_case_status, validate_receipt_number

@router.get("/check/{receipt_number}", response_model=APIResponse)
async def live_status_check(
    receipt_number: str,
    force:          bool           = Query(False),
    current_user:   User           = Depends(get_current_user),
):
    """
    Live USCIS status proxy.
    Called by the frontend's triggerLiveCheck() and inline widget.
    API keys NEVER leave the server.
    """
    num = receipt_number.upper()
    if not validate_receipt_number(num):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid receipt number format. Expected 3 letters + 10 digits.",
        )

    result = await check_case_status(num, force_refresh=force)
    return APIResponse(data=result)
