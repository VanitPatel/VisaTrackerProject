# app/schemas/auth.py
# ═══════════════════════════════════════════════════════
#  Request/response schemas for auth endpoints
# ═══════════════════════════════════════════════════════

from pydantic import BaseModel, EmailStr, field_validator, model_validator
from typing import Optional
import re


class RegisterRequest(BaseModel):
    email:       EmailStr
    password:    str
    first_name:  str
    last_name:   str
    role:        str = "applicant"     # applicant | attorney | hr | dso
    country:     Optional[str] = "us"
    org_name:    Optional[str] = None   # filled for attorney/hr/dso

    @field_validator("password")
    @classmethod
    def strong_password(cls, v: str) -> str:
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters")
        if not re.search(r"[A-Z]", v):
            raise ValueError("Password must contain at least one uppercase letter")
        if not re.search(r"[0-9]", v):
            raise ValueError("Password must contain at least one digit")
        return v

    @field_validator("role")
    @classmethod
    def valid_role(cls, v: str) -> str:
        allowed = {"applicant", "attorney", "hr", "dso"}
        if v not in allowed:
            raise ValueError(f"Role must be one of: {allowed}")
        return v

    @field_validator("first_name", "last_name")
    @classmethod
    def name_not_empty(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Name cannot be empty")
        if len(v) > 100:
            raise ValueError("Name too long")
        return v


class LoginRequest(BaseModel):
    email:    EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token:  str
    refresh_token: str
    token_type:    str = "bearer"
    expires_in:    int   # seconds


class RefreshRequest(BaseModel):
    refresh_token: str


class UserResponse(BaseModel):
    id:         str
    email:      str
    first_name: str
    last_name:  str
    role:       str
    initials:   str
    subscription_tier: str
    is_verified: bool
    created_at: str

    model_config = {"from_attributes": True}


class LoginResponse(BaseModel):
    tokens: TokenResponse
    user:   UserResponse


# app/schemas/case.py

class CaseCreateRequest(BaseModel):
    receipt_number:  str
    visa_type:       Optional[str] = None
    processing_type: str = "Regular"
    notes:           Optional[str] = None
    priority:        str = "low"

    @field_validator("receipt_number")
    @classmethod
    def validate_receipt(cls, v: str) -> str:
        v = v.strip().upper()
        if not re.match(r"^[A-Z]{3}\d{10}$", v):
            raise ValueError("Invalid receipt number format. Expected: 3 letters + 10 digits (e.g. EAC9999103403)")
        return v


class CaseUpdateRequest(BaseModel):
    visa_type:       Optional[str] = None
    notes:           Optional[str] = None
    priority:        Optional[str] = None
    auto_poll_enabled: Optional[bool] = None


class CaseResponse(BaseModel):
    id:             str
    receipt_number: str
    visa_type:      Optional[str]
    form_type:      Optional[str]
    processing_type: str
    status:         str
    priority:       str
    submitted_date: Optional[str]
    modified_date:  Optional[str]
    api_snapshot:   Optional[dict]
    timeline_events: Optional[list]
    last_checked_at: Optional[str]
    created_at:     str

    model_config = {"from_attributes": True}


# app/schemas/document.py

class DocumentResponse(BaseModel):
    id:                  str
    case_id:             str
    name:                str
    doc_type:            str
    file_size_bytes:     Optional[int]
    verification_status: str
    ocr_processed:       bool
    uploaded_at:         str
    download_url:        Optional[str] = None   # signed URL populated at request time

    model_config = {"from_attributes": True}


# app/schemas/notification.py

class NotificationResponse(BaseModel):
    id:         str
    type:       str
    title:      str
    message:    str
    icon:       Optional[str]
    priority:   str
    is_read:    bool
    case_id:    Optional[str]
    created_at: str

    model_config = {"from_attributes": True}


# Shared envelope

class APIResponse(BaseModel):
    success: bool = True
    data:    object = None
    error:   Optional[str] = None
    meta:    Optional[dict] = None
