# app/models/billing.py
import uuid
from datetime import datetime
from sqlalchemy import String, DateTime, ForeignKey, Boolean, Integer, Numeric
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID
import enum
from sqlalchemy import Enum as SAEnum

from config.database import Base


class SubscriptionStatus(str, enum.Enum):
    active   = "active"
    past_due = "past_due"
    canceled = "canceled"
    trialing = "trialing"
    paused   = "paused"


class Subscription(Base):
    __tablename__ = "subscriptions"

    id:                  Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id:             Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), unique=True)
    stripe_customer_id:  Mapped[str | None] = mapped_column(String(100))
    stripe_subscription_id: Mapped[str | None] = mapped_column(String(100), unique=True)
    stripe_price_id:     Mapped[str | None] = mapped_column(String(100))

    plan:                Mapped[str]       = mapped_column(String(30), default="free")   # free | pro | enterprise
    status:              Mapped[SubscriptionStatus] = mapped_column(SAEnum(SubscriptionStatus), default=SubscriptionStatus.active)
    case_limit:          Mapped[int]       = mapped_column(Integer, default=3)
    current_period_end:  Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    trial_end:           Mapped[datetime | None]  = mapped_column(DateTime, nullable=True)
    cancel_at_period_end: Mapped[bool]    = mapped_column(Boolean, default=False)

    created_at:          Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at:          Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Invoice(Base):
    __tablename__ = "invoices"

    id:                  Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id:             Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"))
    stripe_invoice_id:   Mapped[str | None] = mapped_column(String(100), unique=True)

    amount_cents:        Mapped[int]       = mapped_column(Integer, nullable=False)
    currency:            Mapped[str]       = mapped_column(String(10), default="usd")
    status:              Mapped[str]       = mapped_column(String(20))
    invoice_pdf_url:     Mapped[str | None] = mapped_column(String(512))

    paid_at:             Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at:          Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
