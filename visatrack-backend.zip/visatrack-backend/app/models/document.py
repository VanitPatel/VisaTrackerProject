# app/models/document.py
import uuid
from datetime import datetime
from sqlalchemy import String, DateTime, ForeignKey, Boolean, BigInteger
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID
import enum
from sqlalchemy import Enum as SAEnum

from config.database import Base


class VerificationStatus(str, enum.Enum):
    pending    = "pending"
    processing = "processing"
    verified   = "verified"
    rejected   = "rejected"


class Document(Base):
    __tablename__ = "documents"

    id:                  Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    case_id:             Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("cases.id", ondelete="CASCADE"), index=True)
    user_id:             Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"))

    name:                Mapped[str]       = mapped_column(String(255), nullable=False)
    original_filename:   Mapped[str]       = mapped_column(String(255))
    doc_type:            Mapped[str]       = mapped_column(String(100))  # Petition | Notice | Identification | Employment
    mime_type:           Mapped[str | None] = mapped_column(String(100))
    file_size_bytes:     Mapped[int | None] = mapped_column(BigInteger)

    # Storage reference — local path or S3 key
    storage_key:         Mapped[str]       = mapped_column(String(512), nullable=False)

    # Verification
    verification_status: Mapped[VerificationStatus] = mapped_column(SAEnum(VerificationStatus), default=VerificationStatus.pending)
    verified_at:         Mapped[datetime | None]    = mapped_column(DateTime, nullable=True)

    # OCR text (stored in MongoDB for large content)
    ocr_mongo_id:        Mapped[str | None] = mapped_column(String(50), nullable=True)
    ocr_processed:       Mapped[bool]       = mapped_column(Boolean, default=False)

    uploaded_at:         Mapped[datetime]   = mapped_column(DateTime, default=datetime.utcnow)
    updated_at:          Mapped[datetime]   = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    case: Mapped["Case"] = relationship("Case", back_populates="documents")


# ── Notification model ────────────────────────────────
# app/models/notification.py
class NotificationType(str, enum.Enum):
    status   = "status"
    deadline = "deadline"
    document = "document"
    ai       = "ai"
    system   = "system"


class Notification(Base):
    __tablename__ = "notifications"

    id:        Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id:   Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True)
    case_id:   Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("cases.id", ondelete="SET NULL"), nullable=True)

    type:      Mapped[NotificationType] = mapped_column(SAEnum(NotificationType), default=NotificationType.system)
    title:     Mapped[str]   = mapped_column(String(255), nullable=False)
    message:   Mapped[str]   = mapped_column(String(2000), nullable=False)
    icon:      Mapped[str | None] = mapped_column(String(10))
    priority:  Mapped[str]   = mapped_column(String(10), default="normal")   # low | normal | high | urgent

    is_read:       Mapped[bool]       = mapped_column(Boolean, default=False)
    email_sent:    Mapped[bool]       = mapped_column(Boolean, default=False)
    sms_sent:      Mapped[bool]       = mapped_column(Boolean, default=False)
    push_sent:     Mapped[bool]       = mapped_column(Boolean, default=False)

    created_at:    Mapped[datetime]   = mapped_column(DateTime, default=datetime.utcnow)
    read_at:       Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    user: Mapped["User"] = relationship("User", back_populates="notifications")
