# app/models/user.py
# ═══════════════════════════════════════════════════════
#  User model — supports 5 roles, org membership, MFA
# ═══════════════════════════════════════════════════════

import uuid
from datetime import datetime
from sqlalchemy import (
    String, Boolean, DateTime, ForeignKey, Text, Enum as SAEnum
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID
import enum

from config.database import Base


class UserRole(str, enum.Enum):
    applicant = "applicant"
    attorney  = "attorney"
    hr        = "hr"
    dso       = "dso"
    admin     = "admin"


class SubscriptionTier(str, enum.Enum):
    free       = "free"
    pro        = "pro"
    enterprise = "enterprise"


class Organization(Base):
    __tablename__ = "organizations"

    id:           Mapped[uuid.UUID]  = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name:         Mapped[str]        = mapped_column(String(255), nullable=False)
    domain:       Mapped[str | None] = mapped_column(String(255))
    plan:         Mapped[str]        = mapped_column(String(50), default="free")
    created_at:   Mapped[datetime]   = mapped_column(DateTime, default=datetime.utcnow)

    users: Mapped[list["User"]] = relationship("User", back_populates="organization")


class User(Base):
    __tablename__ = "users"

    id:                 Mapped[uuid.UUID]    = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email:              Mapped[str]          = mapped_column(String(320), unique=True, nullable=False, index=True)
    password_hash:      Mapped[str]          = mapped_column(String(255), nullable=False)
    first_name:         Mapped[str]          = mapped_column(String(100), nullable=False)
    last_name:          Mapped[str]          = mapped_column(String(100), nullable=False)
    role:               Mapped[UserRole]     = mapped_column(SAEnum(UserRole), nullable=False, default=UserRole.applicant)
    subscription_tier:  Mapped[SubscriptionTier] = mapped_column(SAEnum(SubscriptionTier), default=SubscriptionTier.free)
    organization_id:    Mapped[uuid.UUID | None]  = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=True)
    country:            Mapped[str | None]   = mapped_column(String(10))
    phone:              Mapped[str | None]   = mapped_column(String(30))

    # Account state
    is_active:          Mapped[bool]         = mapped_column(Boolean, default=True)
    is_verified:        Mapped[bool]         = mapped_column(Boolean, default=False)
    email_verified_at:  Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    # MFA
    mfa_enabled:        Mapped[bool]         = mapped_column(Boolean, default=False)
    mfa_secret:         Mapped[str | None]   = mapped_column(String(64), nullable=True)

    # Notifications preferences (JSON string)
    notif_prefs:        Mapped[str | None]   = mapped_column(Text, nullable=True)

    # Timestamps
    created_at:         Mapped[datetime]     = mapped_column(DateTime, default=datetime.utcnow)
    updated_at:         Mapped[datetime]     = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login_at:      Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    # Relationships
    organization: Mapped[Organization | None] = relationship("Organization", back_populates="users")
    cases:         Mapped[list["Case"]]        = relationship("Case", back_populates="user", cascade="all, delete-orphan")
    notifications: Mapped[list["Notification"]] = relationship("Notification", back_populates="user", cascade="all, delete-orphan")
    refresh_tokens: Mapped[list["RefreshToken"]] = relationship("RefreshToken", back_populates="user", cascade="all, delete-orphan")

    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}".strip()

    @property
    def initials(self) -> str:
        return ((self.first_name[:1]) + (self.last_name[:1])).upper()


class RefreshToken(Base):
    """Stored refresh tokens — supports rotation & revocation."""
    __tablename__ = "refresh_tokens"

    id:         Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id:    Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"))
    token_hash: Mapped[str]       = mapped_column(String(255), unique=True, nullable=False)
    expires_at: Mapped[datetime]  = mapped_column(DateTime, nullable=False)
    revoked:    Mapped[bool]      = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime]  = mapped_column(DateTime, default=datetime.utcnow)
    user_agent: Mapped[str | None] = mapped_column(String(512), nullable=True)
    ip_address: Mapped[str | None] = mapped_column(String(64), nullable=True)

    user: Mapped[User] = relationship("User", back_populates="refresh_tokens")
