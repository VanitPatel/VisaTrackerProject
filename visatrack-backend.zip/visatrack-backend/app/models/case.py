# app/models/case.py
# ═══════════════════════════════════════════════════════
#  Visa Case model — links to USCIS receipt numbers
#  Timeline events stored as JSONB for flexibility
# ═══════════════════════════════════════════════════════

import uuid
from datetime import datetime
from typing import Any
from sqlalchemy import String, DateTime, ForeignKey, Text, JSON, Boolean, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID, JSONB
import enum
from sqlalchemy import Enum as SAEnum

from config.database import Base


class CaseStatus(str, enum.Enum):
    pending     = "pending"
    in_progress = "in_progress"
    rfe         = "rfe"
    approved    = "approved"
    denied      = "denied"
    withdrawn   = "withdrawn"
    transferred = "transferred"
    unknown     = "unknown"


class ProcessingType(str, enum.Enum):
    regular = "Regular"
    premium = "Premium"


class Case(Base):
    __tablename__ = "cases"

    id:              Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id:         Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True)

    # USCIS receipt number (e.g. EAC9999103403)
    receipt_number:  Mapped[str]       = mapped_column(String(20), nullable=False, index=True)
    visa_type:       Mapped[str | None] = mapped_column(String(100))
    form_type:       Mapped[str | None] = mapped_column(String(20))
    processing_type: Mapped[ProcessingType] = mapped_column(SAEnum(ProcessingType), default=ProcessingType.regular)

    # Priority for attorney/HR dashboards
    priority:        Mapped[str]       = mapped_column(String(10), default="low")  # low | med | high

    # Dates from USCIS
    submitted_date:  Mapped[str | None] = mapped_column(String(30))   # string from API
    modified_date:   Mapped[str | None] = mapped_column(String(30))

    # Normalised status (our enum)
    status:          Mapped[CaseStatus] = mapped_column(SAEnum(CaseStatus), default=CaseStatus.unknown)

    # Raw USCIS API snapshot — full response stored as JSONB
    api_snapshot:    Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    # Timeline events — list of {date, event, source}
    timeline_events: Mapped[list | None] = mapped_column(JSONB, default=list)

    # Custom notes (attorney/HR)
    notes:           Mapped[str | None] = mapped_column(Text)

    # Deadlines
    response_deadline: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    expiry_date:       Mapped[datetime | None]  = mapped_column(DateTime, nullable=True)

    # Auto-poll
    auto_poll_enabled: Mapped[bool]    = mapped_column(Boolean, default=True)
    last_checked_at:   Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    # Timestamps
    created_at:       Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at:       Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    user:      Mapped["User"]            = relationship("User", back_populates="cases")
    documents: Mapped[list["Document"]]  = relationship("Document", back_populates="case", cascade="all, delete-orphan")
