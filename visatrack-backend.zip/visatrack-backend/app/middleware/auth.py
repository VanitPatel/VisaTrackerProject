# app/middleware/auth.py
# ═══════════════════════════════════════════════════════
#  FastAPI dependencies for JWT auth + RBAC
#  Usage:
#    @router.get("/...", dependencies=[Depends(require_role("attorney"))])
#    async def endpoint(current_user = Depends(get_current_user)):
# ═══════════════════════════════════════════════════════

from typing import Optional, List
from fastapi import Depends, HTTPException, status, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.models.user import User
from app.services.auth_service import decode_access_token
from config.database import get_db

bearer_scheme = HTTPBearer(auto_error=False)


async def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Security(bearer_scheme),
    db: AsyncSession = Depends(get_db),
) -> User:
    """Extract and validate JWT; return the User object."""
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
            headers={"WWW-Authenticate": "Bearer"},
        )
    try:
        payload = decode_access_token(credentials.credentials)
        user_id = payload.get("sub")
        if not user_id:
            raise JWTError("Missing sub claim")
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    result = await db.execute(select(User).where(User.id == user_id))
    user: Optional[User] = result.scalar_one_or_none()
    if not user or not user.is_active:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found or deactivated")
    return user


def require_role(*roles: str):
    """Dependency factory — enforces RBAC at the route level."""
    async def _check(current_user: User = Depends(get_current_user)):
        if current_user.role.value not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Access restricted to roles: {list(roles)}",
            )
        return current_user
    return _check


# Convenience shortcuts
require_attorney_or_admin = require_role("attorney", "admin")
require_hr_or_admin       = require_role("hr", "admin")
require_dso_or_admin      = require_role("dso", "admin")
require_admin             = require_role("admin")


# ─────────────────────────────────────────────────────
# app/middleware/rate_limit.py
# ─────────────────────────────────────────────────────

from slowapi import Limiter
from slowapi.util import get_remote_address
from config.settings import settings

limiter = Limiter(key_func=get_remote_address)


# ─────────────────────────────────────────────────────
# app/middleware/logging.py
# ─────────────────────────────────────────────────────

import time
import uuid as _uuid
import structlog
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

log = structlog.get_logger()


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next) -> Response:
        req_id  = str(_uuid.uuid4())[:8]
        start   = time.perf_counter()

        # Bind request context to the log
        structlog.contextvars.bind_contextvars(
            req_id=req_id,
            method=request.method,
            path=request.url.path,
        )

        response = await call_next(request)

        duration_ms = round((time.perf_counter() - start) * 1000, 1)
        log.info(
            "http.request",
            status=response.status_code,
            duration_ms=duration_ms,
            ip=request.client.host if request.client else "—",
        )
        structlog.contextvars.clear_contextvars()
        response.headers["X-Request-ID"] = req_id
        return response
