# app/services/auth_service.py
# ═══════════════════════════════════════════════════════
#  Auth service — registration, login, token lifecycle
# ═══════════════════════════════════════════════════════

import hashlib
import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional, Tuple

from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
import structlog

from app.models.user import User, RefreshToken, UserRole
from config.settings import settings

log = structlog.get_logger()

# bcrypt hasher
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

JWT_ALGORITHM  = settings.jwt_algorithm
ACCESS_EXPIRE  = timedelta(minutes=settings.jwt_access_token_expire_minutes)
REFRESH_EXPIRE = timedelta(days=settings.jwt_refresh_token_expire_days)


# ── Password ──────────────────────────────────────────

def hash_password(plain: str) -> str:
    return pwd_context.hash(plain)


def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)


# ── Token creation ────────────────────────────────────

def _make_access_token(user_id: str, role: str, email: str) -> str:
    now    = datetime.now(timezone.utc)
    claims = {
        "sub":   user_id,
        "role":  role,
        "email": email,
        "iat":   now,
        "exp":   now + ACCESS_EXPIRE,
        "type":  "access",
    }
    return jwt.encode(claims, settings.jwt_secret_key, algorithm=JWT_ALGORITHM)


def _make_refresh_token() -> str:
    """Opaque random token — stored as hash in DB."""
    return str(uuid.uuid4()) + "-" + str(uuid.uuid4())


def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


# ── Token verification ────────────────────────────────

def decode_access_token(token: str) -> dict:
    """Raises JWTError on invalid/expired token."""
    payload = jwt.decode(
        token,
        settings.jwt_secret_key,
        algorithms=[JWT_ALGORITHM],
    )
    if payload.get("type") != "access":
        raise JWTError("Not an access token")
    return payload


# ── Registration ──────────────────────────────────────

async def register_user(
    db:         AsyncSession,
    email:      str,
    password:   str,
    first_name: str,
    last_name:  str,
    role:       str = "applicant",
    country:    str = "us",
) -> User:
    # Check uniqueness
    result = await db.execute(select(User).where(User.email == email.lower()))
    if result.scalar_one_or_none():
        raise ValueError("Email already registered")

    user = User(
        email          = email.lower(),
        password_hash  = hash_password(password),
        first_name     = first_name.strip(),
        last_name      = last_name.strip(),
        role           = UserRole(role),
        country        = country,
    )
    db.add(user)
    await db.flush()   # get the ID
    log.info("user.registered", user_id=str(user.id), role=role)
    return user


# ── Login ─────────────────────────────────────────────

async def authenticate_user(db: AsyncSession, email: str, password: str) -> User:
    result = await db.execute(select(User).where(User.email == email.lower()))
    user: Optional[User] = result.scalar_one_or_none()
    if not user or not verify_password(password, user.password_hash):
        raise ValueError("Invalid email or password")
    if not user.is_active:
        raise ValueError("Account is deactivated")
    user.last_login_at = datetime.utcnow()
    return user


# ── Issue token pair ──────────────────────────────────

async def issue_tokens(
    db:         AsyncSession,
    user:       User,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None,
) -> Tuple[str, str]:
    """Returns (access_token, refresh_token)."""
    access  = _make_access_token(str(user.id), user.role.value, user.email)
    refresh = _make_refresh_token()

    rt = RefreshToken(
        user_id    = user.id,
        token_hash = _hash_token(refresh),
        expires_at = datetime.utcnow() + REFRESH_EXPIRE,
        ip_address = ip_address,
        user_agent = user_agent,
    )
    db.add(rt)
    return access, refresh


# ── Refresh ───────────────────────────────────────────

async def rotate_refresh_token(
    db:            AsyncSession,
    refresh_token: str,
    ip_address:    Optional[str] = None,
    user_agent:    Optional[str] = None,
) -> Tuple[str, str]:
    token_hash = _hash_token(refresh_token)
    result = await db.execute(
        select(RefreshToken)
        .where(RefreshToken.token_hash == token_hash)
        .where(RefreshToken.revoked == False)  # noqa: E712
    )
    rt: Optional[RefreshToken] = result.scalar_one_or_none()

    if not rt or rt.expires_at < datetime.utcnow():
        raise ValueError("Invalid or expired refresh token")

    # Revoke old token (rotation)
    rt.revoked = True

    # Fetch user
    user_result = await db.execute(select(User).where(User.id == rt.user_id))
    user: User = user_result.scalar_one()

    return await issue_tokens(db, user, ip_address, user_agent)


# ── Logout (revoke refresh token) ─────────────────────

async def revoke_refresh_token(db: AsyncSession, refresh_token: str):
    token_hash = _hash_token(refresh_token)
    result = await db.execute(
        select(RefreshToken).where(RefreshToken.token_hash == token_hash)
    )
    rt = result.scalar_one_or_none()
    if rt:
        rt.revoked = True
        log.info("token.revoked", user_id=str(rt.user_id))
