# app/services/case_service.py
# ═══════════════════════════════════════════════════════
#  Case CRUD + USCIS status refresh + deadline tracking
# ═══════════════════════════════════════════════════════

import uuid
from datetime import datetime
from typing import Optional, List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
import structlog

from app.models.case import Case, CaseStatus
from app.services.uscis_service import check_case_status, validate_receipt_number

log = structlog.get_logger()


async def get_user_cases(db: AsyncSession, user_id: uuid.UUID) -> List[Case]:
    result = await db.execute(
        select(Case).where(Case.user_id == user_id).order_by(Case.created_at.desc())
    )
    return result.scalars().all()


async def get_case(db: AsyncSession, case_id: uuid.UUID, user_id: uuid.UUID) -> Optional[Case]:
    result = await db.execute(
        select(Case).where(and_(Case.id == case_id, Case.user_id == user_id))
    )
    return result.scalar_one_or_none()


async def create_case(
    db:              AsyncSession,
    user_id:         uuid.UUID,
    receipt_number:  str,
    visa_type:       Optional[str]  = None,
    processing_type: str            = "Regular",
    notes:           Optional[str]  = None,
    priority:        str            = "low",
) -> Case:
    if not validate_receipt_number(receipt_number):
        raise ValueError("Invalid USCIS receipt number format")

    # Check for duplicate
    existing = await db.execute(
        select(Case).where(and_(Case.user_id == user_id, Case.receipt_number == receipt_number.upper()))
    )
    if existing.scalar_one_or_none():
        raise ValueError("This receipt number is already tracked")

    case = Case(
        user_id         = user_id,
        receipt_number  = receipt_number.upper(),
        visa_type       = visa_type,
        processing_type = processing_type,
        notes           = notes,
        priority        = priority,
    )
    db.add(case)
    await db.flush()

    # Immediately fetch USCIS status
    await _refresh_case_status(db, case)
    log.info("case.created", case_id=str(case.id), receipt=receipt_number)
    return case


async def update_case(
    db:       AsyncSession,
    case:     Case,
    **fields,
) -> Case:
    for k, v in fields.items():
        if v is not None and hasattr(case, k):
            setattr(case, k, v)
    return case


async def delete_case(db: AsyncSession, case: Case):
    await db.delete(case)
    log.info("case.deleted", case_id=str(case.id))


async def refresh_case_status(db: AsyncSession, case: Case, force: bool = False) -> dict:
    return await _refresh_case_status(db, case, force)


async def _refresh_case_status(db: AsyncSession, case: Case, force: bool = True) -> dict:
    result = await check_case_status(case.receipt_number, force_refresh=force)
    if not result.get("error"):
        case.api_snapshot   = result
        case.form_type      = result.get("form_type") or case.form_type
        case.submitted_date = result.get("submitted_date") or case.submitted_date
        case.modified_date  = result.get("modified_date")  or case.modified_date
        case.status         = CaseStatus(result.get("status_normalised", "unknown"))
        case.last_checked_at = datetime.utcnow()
        # Merge history into timeline_events
        history = result.get("history", [])
        if history:
            case.timeline_events = history
    return result


# ─────────────────────────────────────────────────────
# app/services/notification_service.py
# ─────────────────────────────────────────────────────

import uuid
from typing import List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from app.models.document import Notification, NotificationType


async def get_user_notifications(
    db:      AsyncSession,
    user_id: uuid.UUID,
    unread_only: bool = False,
    limit:   int = 50,
) -> List[Notification]:
    q = select(Notification).where(Notification.user_id == user_id)
    if unread_only:
        q = q.where(Notification.is_read == False)  # noqa: E712
    q = q.order_by(Notification.created_at.desc()).limit(limit)
    result = await db.execute(q)
    return result.scalars().all()


async def mark_read(db: AsyncSession, notif_id: uuid.UUID, user_id: uuid.UUID) -> bool:
    result = await db.execute(
        select(Notification).where(
            and_(Notification.id == notif_id, Notification.user_id == user_id)
        )
    )
    n = result.scalar_one_or_none()
    if n:
        n.is_read = True
        n.read_at = datetime.utcnow()
        return True
    return False


async def mark_all_read(db: AsyncSession, user_id: uuid.UUID):
    from sqlalchemy import update
    await db.execute(
        update(Notification)
        .where(and_(Notification.user_id == user_id, Notification.is_read == False))
        .values(is_read=True, read_at=datetime.utcnow())
    )


async def push_notification(
    db:       AsyncSession,
    user_id:  uuid.UUID,
    title:    str,
    message:  str,
    type:     NotificationType = NotificationType.system,
    case_id:  Optional[uuid.UUID] = None,
    icon:     str = "🔔",
    priority: str = "normal",
) -> Notification:
    n = Notification(
        user_id  = user_id,
        case_id  = case_id,
        type     = type,
        title    = title,
        message  = message,
        icon     = icon,
        priority = priority,
    )
    db.add(n)
    await db.flush()
    return n


# ─────────────────────────────────────────────────────
# app/services/ai_service.py
# ─────────────────────────────────────────────────────

"""
AI chat service.
- All OpenAI API calls happen here — key never leaves the server.
- Simple RAG stub included: injects case context into system prompt.
"""

from openai import AsyncOpenAI
import structlog as _log

_ailog = _log.get_logger()

SYSTEM_PROMPT = """You are an expert US immigration assistant working for VisaTrack Pro.
You help applicants, attorneys, HR managers, and DSOs understand USCIS case statuses,
respond to RFEs, prepare for interviews, and navigate immigration processes.
Be factual, empathetic, and always recommend consulting a licensed immigration attorney
for specific legal advice. Keep answers concise and actionable."""


async def ai_chat(
    user_message: str,
    case_context: Optional[dict] = None,
    history:      Optional[list]  = None,
) -> str:
    from config.settings import settings as _s
    if not _s.openai_api_key:
        return _stub_reply(user_message, case_context)

    client = AsyncOpenAI(api_key=_s.openai_api_key)

    # Build context-enriched system prompt
    system = SYSTEM_PROMPT
    if case_context:
        system += f"\n\nUser's current case context:\n{case_context}"

    messages = [{"role": "system", "content": system}]
    if history:
        messages.extend(history[-10:])   # last 10 turns for context window
    messages.append({"role": "user", "content": user_message})

    try:
        response = await client.chat.completions.create(
            model       = _s.openai_model,
            messages    = messages,
            max_tokens  = _s.openai_max_tokens,
            temperature = 0.4,
        )
        return response.choices[0].message.content
    except Exception as e:
        _ailog.error("ai.chat_error", err=str(e))
        return "I'm temporarily unavailable. Please try again shortly."


def _stub_reply(msg: str, ctx: Optional[dict]) -> str:
    """Fallback when OpenAI key not configured."""
    m = msg.lower()
    if "rfe" in m:
        return ("For an RFE: read the notice carefully, gather all requested evidence, "
                "and submit a well-organised package before the deadline. "
                "Consider engaging an immigration attorney.")
    if "status" in m or "case" in m:
        cases = ctx.get("cases", []) if ctx else []
        if cases:
            return f"You have {len(cases)} case(s) tracked: " + ", ".join(c.get("receipt_number","") for c in cases)
        return "You haven't added any cases yet. Go to Cases and add your USCIS receipt number."
    return ("I can help with visa status, RFE guidance, processing timelines, "
            "interview prep, and general immigration questions.")
