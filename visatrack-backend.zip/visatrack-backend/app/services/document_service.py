# app/services/document_service.py
# ═══════════════════════════════════════════════════════
#  Document storage — local filesystem or S3
#  Handles upload, signed URL generation, file validation
# ═══════════════════════════════════════════════════════

import os
import uuid
import hashlib
import mimetypes
from pathlib import Path
from typing import Optional
import aiofiles
import structlog

from config.settings import settings

log = structlog.get_logger()

ALLOWED_MIME_TYPES = {
    "application/pdf",
    "image/jpeg",
    "image/png",
    "image/webp",
    "image/tiff",
}

MAX_BYTES = settings.max_upload_mb * 1024 * 1024


def _validate_file(filename: str, content_type: str, size: int):
    if size > MAX_BYTES:
        raise ValueError(f"File too large (max {settings.max_upload_mb}MB)")
    if content_type not in ALLOWED_MIME_TYPES:
        raise ValueError(f"Unsupported file type: {content_type}. Allowed: PDF, JPG, PNG, WEBP, TIFF")


async def save_document_local(
    file_bytes:   bytes,
    filename:     str,
    content_type: str,
    user_id:      str,
    case_id:      str,
) -> str:
    """Save file locally; return the storage key (relative path)."""
    _validate_file(filename, content_type, len(file_bytes))

    ext = Path(filename).suffix.lower() or ".bin"
    file_id = str(uuid.uuid4())
    relative_path = f"users/{user_id}/cases/{case_id}/{file_id}{ext}"
    abs_path = Path(settings.local_upload_dir) / relative_path

    abs_path.parent.mkdir(parents=True, exist_ok=True)
    async with aiofiles.open(abs_path, "wb") as f:
        await f.write(file_bytes)

    log.info("document.saved_local", path=str(relative_path), size=len(file_bytes))
    return relative_path


async def save_document_s3(
    file_bytes:   bytes,
    filename:     str,
    content_type: str,
    user_id:      str,
    case_id:      str,
) -> str:
    """Upload to S3; return the S3 object key."""
    import boto3
    _validate_file(filename, content_type, len(file_bytes))

    ext = Path(filename).suffix.lower()
    key = f"users/{user_id}/cases/{case_id}/{uuid.uuid4()}{ext}"

    s3 = boto3.client(
        "s3",
        aws_access_key_id     = settings.aws_access_key_id,
        aws_secret_access_key = settings.aws_secret_access_key,
        region_name           = settings.aws_s3_region,
    )
    s3.put_object(
        Bucket      = settings.aws_s3_bucket,
        Key         = key,
        Body        = file_bytes,
        ContentType = content_type,
        ServerSideEncryption = "AES256",
    )
    log.info("document.saved_s3", key=key, size=len(file_bytes))
    return key


async def save_document(
    file_bytes:   bytes,
    filename:     str,
    content_type: str,
    user_id:      str,
    case_id:      str,
) -> str:
    if settings.storage_backend == "s3":
        return await save_document_s3(file_bytes, filename, content_type, user_id, case_id)
    return await save_document_local(file_bytes, filename, content_type, user_id, case_id)


def get_download_url(storage_key: str, expires_in: int = 3600) -> Optional[str]:
    """Returns a presigned URL (S3) or a local download path."""
    if settings.storage_backend == "s3":
        import boto3
        s3 = boto3.client(
            "s3",
            aws_access_key_id     = settings.aws_access_key_id,
            aws_secret_access_key = settings.aws_secret_access_key,
            region_name           = settings.aws_s3_region,
        )
        return s3.generate_presigned_url(
            "get_object",
            Params={"Bucket": settings.aws_s3_bucket, "Key": storage_key},
            ExpiresIn=expires_in,
        )
    # Local: return a backend-signed endpoint
    return f"/api/documents/download/{storage_key}"


async def read_document_local(storage_key: str) -> bytes:
    abs_path = Path(settings.local_upload_dir) / storage_key
    async with aiofiles.open(abs_path, "rb") as f:
        return await f.read()
