# app/services/uscis_service.py
# ═══════════════════════════════════════════════════════
#  USCIS Case Status API — secure server-side proxy
#
#  Flow:
#    1. Acquire OAuth2 token (client_credentials) — cached
#    2. Call /case-status/{receiptNum} with Bearer token
#    3. Parse + normalise response
#    4. Cache result in Redis (TTL = USCIS_CACHE_TTL)
#    5. Return structured dict to caller
#
#  NEVER exposes client_id/secret to the browser.
# ═══════════════════════════════════════════════════════

import re
import time
from typing import Optional
import httpx
import structlog
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

from config.settings import settings
from config.redis import cache_get, cache_set, cache_delete

log = structlog.get_logger()

_token_store: dict = {}   # in-process token cache (process-level, < Redis)

RECEIPT_RE = re.compile(r"^[A-Z]{3}\d{10}$")


def validate_receipt_number(num: str) -> bool:
    return bool(RECEIPT_RE.match(num.upper()))


# ── OAuth token acquisition ───────────────────────────

async def _get_oauth_token() -> str:
    """Returns a valid USCIS OAuth2 access token, refreshing as needed."""
    now = time.time()
    cached = _token_store.get("uscis_token")
    if cached and cached["expires_at"] > now + 30:
        return cached["value"]

    log.info("uscis.token_request")
    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.post(
            settings.uscis_token_url,
            data={
                "grant_type":    "client_credentials",
                "client_id":     settings.uscis_client_id,
                "client_secret": settings.uscis_client_secret,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )

    if resp.status_code != 200:
        raise RuntimeError(f"USCIS token error {resp.status_code}: {resp.text[:200]}")

    data  = resp.json()
    token = data.get("access_token") or data.get("accessToken")
    if not token:
        raise RuntimeError(f"No access_token in USCIS response: {data}")

    expires_in = int(data.get("expires_in", 3600))
    _token_store["uscis_token"] = {
        "value":      token,
        "expires_at": now + expires_in,
    }
    log.info("uscis.token_acquired", expires_in=expires_in)
    return token


# ── Status normaliser ─────────────────────────────────

def _normalise_status(text: str) -> str:
    """Map USCIS status text → our CaseStatus enum string."""
    if not text:
        return "unknown"
    t = text.lower()
    if "approved" in t or "approval" in t:
        return "approved"
    if "denied" in t or "denial" in t:
        return "denied"
    if "request for evidence" in t or "rfe" in t:
        return "rfe"
    if "transfer" in t:
        return "transferred"
    if "withdrawn" in t:
        return "withdrawn"
    if "received" in t or "receipt" in t:
        return "in_progress"
    return "in_progress"


def _badge_for_status(normalised: str) -> str:
    MAP = {
        "approved":    "b-emerald",
        "denied":      "b-rose",
        "rfe":         "b-amber",
        "transferred": "b-sky",
        "withdrawn":   "b-muted",
        "in_progress": "b-teal",
        "unknown":     "b-muted",
    }
    return MAP.get(normalised, "b-sky")


def _parse_response(json_data: dict, receipt_num: str) -> dict:
    """Normalise raw USCIS JSON into a frontend-friendly dict."""
    cs = json_data.get("case_status") or json_data

    raw_status  = cs.get("current_case_status_text_en") or cs.get("status", "")
    description = cs.get("current_case_status_desc_en") or cs.get("description", "")
    normalised  = _normalise_status(raw_status)

    history = [
        {
            "date":               h.get("date", ""),
            "completed_text_en":  h.get("completed_text_en", ""),
            "completed_text_es":  h.get("completed_text_es", ""),
        }
        for h in cs.get("hist_case_status", [])
    ]

    return {
        "receipt_number":  cs.get("receiptNumber", receipt_num),
        "form_type":       cs.get("formType", ""),
        "submitted_date":  (cs.get("submittedDate") or "")[:10],
        "modified_date":   (cs.get("modifiedDate")  or "")[:10],
        "status":          raw_status,
        "status_normalised": normalised,
        "description":     description,
        "label":           raw_status,
        "badge":           _badge_for_status(normalised),
        "history":         history,
        "raw":             json_data,   # full snapshot stored in DB
    }


# ── Main check function ───────────────────────────────

@retry(
    stop=stop_after_attempt(2),
    wait=wait_exponential(multiplier=1, min=1, max=4),
    retry=retry_if_exception_type(httpx.TransportError),
    reraise=True,
)
async def check_case_status(receipt_num: str, force_refresh: bool = False) -> dict:
    """
    Returns normalised case status dict.
    Caches result in Redis for USCIS_CACHE_TTL seconds.
    """
    num = receipt_num.upper()
    cache_key = f"uscis:status:{num}"

    # Try cache first
    if not force_refresh:
        cached = await cache_get(cache_key)
        if cached:
            cached["source"] = "cache"
            return cached

    log.info("uscis.api_call", receipt=num)
    try:
        token = await _get_oauth_token()
        url   = f"{settings.uscis_api_base}/case-status/{num}"

        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.get(
                url,
                headers={
                    "Authorization": f"Bearer {token}",
                    "Accept":        "application/json",
                },
            )

        if resp.status_code == 404:
            return {
                "error":  "Receipt number not found in USCIS system",
                "badge":  "b-muted",
                "label":  "Not Found",
                "source": "uscis_api",
            }
        if resp.status_code != 200:
            return {
                "error":  f"USCIS API error {resp.status_code}",
                "badge":  "b-rose",
                "label":  "API Error",
                "source": "uscis_api",
            }

        result = _parse_response(resp.json(), num)
        result["source"] = "uscis_api"

        # Store in Redis
        await cache_set(cache_key, result, ttl=settings.uscis_cache_ttl)
        log.info("uscis.status_ok", receipt=num, status=result.get("status_normalised"))
        return result

    except httpx.TransportError as e:
        log.warning("uscis.transport_error", receipt=num, err=str(e))
        raise   # tenacity will retry
    except Exception as e:
        log.error("uscis.unexpected_error", receipt=num, err=str(e))
        return {
            "error":  str(e),
            "badge":  "b-rose",
            "label":  "Error",
            "source": "error",
        }


async def invalidate_case_cache(receipt_num: str):
    await cache_delete(f"uscis:status:{receipt_num.upper()}")
